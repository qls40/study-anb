package com.javalec.six;

public class callByValue {
	int add(int a, int b) 
	{
	    return a + b;
	}
	int a1 = 10;
	int a2 = 20;
	cout  add(a1, a2) end1;

}
