package com.javalec.two;

public class ConstructorDemo{
	
	public ConstructorDemo() {}
    public ConstructorDemo(int param1){}
    public static void main (String[] args){
        ConstructorDemo c = new ConstructorDemo();
    }
}