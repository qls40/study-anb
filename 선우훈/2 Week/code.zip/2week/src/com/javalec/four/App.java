package com.javalec.four;

class Person{
	
	public Person(String name) {
		this.name = name;
		
	}
	public String toString() {
		return name;
	}
	private String name;
}


public class App{
	public static void main(String[] args) {
		Person p = new Person("Hoon");
		System.out.println(p);
		
	}
}