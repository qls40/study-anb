package com.javalec.five;

public class App {

	

	static String conString(String... args) {
		String result = "";
		
		for (String str : args) {
			result += str;
		}
		return result;
	}
	
	public static void main(String[] args) {
		String str1 = "Hi";
		String str2 = " Hoon";
		String str3 = " insta";
		String str4 = " sunwoo_h";
		String str5 = "�Դϴ�.";
		
		String result = conString(str1, str2, str3, str4, str5);
		System.out.println("�����:" + result);
	}
}

