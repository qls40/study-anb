package com.javalec.one;

public class ConstructorDemo{
public static void main(String[] args){
    ConstructorDemo c = new ConstructorDemo();
    }
} 