package com.javalec.three;

class Person{
	
	public Person(String name) {
		this.name = name;
		
	}
	private String name;
}


public class App{
	public static void main(String[] args) {
		Person p = new Person("Hoon");
		System.out.println(p);
		
	}
}