package com.javalec.study.three;
import java.math.BigDecimal;

public class MainClass {

	public static void main(String[] args) {
		// 3. 부동소수점
		FloatingPointClass FPC = new FloatingPointClass();
		FPC.method();
		
	}
}
