package com.javalec.study.eight;

public class ParentClass {

	public void Method() {
		System.out.println("ParentClass에서 작성된 Method 입니다.");
	}
	
	public void FinalMethod() {
		System.out.println("ParentClass에서 작성된 Final로 선언된 Method입니다.");
	}
}


