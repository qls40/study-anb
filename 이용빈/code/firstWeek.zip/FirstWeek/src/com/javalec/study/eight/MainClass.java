package com.javalec.study.eight;

public class MainClass {

    
	public static void main(String[] args) {

	}
	
}
