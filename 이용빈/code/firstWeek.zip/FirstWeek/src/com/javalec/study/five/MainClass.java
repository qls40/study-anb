package com.javalec.study.five;

import com.javalec.study.five.LogicalOperationClass;

public class MainClass {

	public static void main(String[] args) {
		//5.논리연산
		LogicalOperationClass LOC = new LogicalOperationClass();
		LOC.method();
		
	}

}
