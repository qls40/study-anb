package com.javalec.study.four;

import com.javalec.study.four.OperatorCalcClass;

public class MainClass {

	public static void main(String[] args) {
		
		OperatorCalcClass OCC = new OperatorCalcClass();
		OCC.method();
		System.out.println();
		
	}

}
