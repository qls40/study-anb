package com.javalec.study4;

public class CarClass {
	private String name;
	private String color;
	private int price;
	public CarClass() {
		
	}
	
	public CarClass(String name, String color,int price) {
		this.name = name;
		this.color = color;
		this.price = price;
		
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getColor() {
		return color;
	}

	public void setColor(String color) {
		this.color = color;
	}

	public int getPrice() {
		return price;
	}

	public void setPrice(int price) {
		this.price = price;
	}

	@Override
	public String toString() {
		return "CarClass [이름 : " + name + ", 색상  : " + color + ", 가격 :" + price + "]";
	}
	
	
	
}
