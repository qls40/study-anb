package com.javalec.study4;

public class MainClass {

	public static void main(String[] args) {
		CarClass car1 = new CarClass("sonata","white",15000000);
		System.out.println(car1.toString());
		System.out.println();
		
		CarClass car2 = new CarClass("Avante","black",12000000);
		System.out.println(car2.toString());
		System.out.println();
		
		CarClass car3 = new CarClass("Sorento","silver",22000000);
		System.out.println(car3.toString());
		System.out.println();
		
	}

}
