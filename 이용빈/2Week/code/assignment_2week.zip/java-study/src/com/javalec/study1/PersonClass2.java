package com.javalec.study1;

public class PersonClass2 {
	private String userid;
	private String userpw;
	
	public PersonClass2(String userid){
		this.userid = userid;
	}
}
