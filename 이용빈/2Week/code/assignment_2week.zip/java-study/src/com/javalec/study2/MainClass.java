package com.javalec.study2;

public class MainClass {

	public static void main(String[] args) {
		PersonClass3 person4 = new PersonClass3();
		PersonClass3 person1 = new PersonClass3("leeyongbin");
		PersonClass3 person2 = new PersonClass3(1234);
		PersonClass3 person3 = new PersonClass3("leeyongbin",1234);
		
	}
}

