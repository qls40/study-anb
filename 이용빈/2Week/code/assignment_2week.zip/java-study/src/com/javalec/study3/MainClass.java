package com.javalec.study3;

public class MainClass {

	public static void main(String[] args) {
		CarClass car = new CarClass("sonata","white",10000000);
		System.out.println(car.toString());
	}

}
