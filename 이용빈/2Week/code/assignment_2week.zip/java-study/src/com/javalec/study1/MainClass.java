package com.javalec.study1;

public class MainClass {

	public static void main(String[] args) {
		//무인 생섵자만 가지는 코드
		PersonClass1 person1 = new PersonClass1();
		
		//인자 1개가 있는 생성자를 가지는 코드
		//PersonClass2 person2 = new PersonClass2();
		
	}

}
